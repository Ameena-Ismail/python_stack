from django.apps import AppConfig


class AmeenaAppConfig(AppConfig):
    name = 'ameena_app'
